<html lang="en">
<?php if(\Session::has('kasir') || \Session::has('admin')): ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Invoice</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <style>
        body{
            font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            color:#333;
            text-align:left;
            font-size:14px;
            margin:0;
        }
        .container{
            margin:0 auto;
            margin-top:25px;
            padding:20px;
            width:950px;
            height:auto;
            background-color:#fff;
        }
        caption{
            font-size:28px;
            margin-bottom:15px;
        }
        table{
            border:0px solid #333;
            margin:0 auto;
            width:780px;
        }
        td, tr, th{
            padding:12px;
            border:1px solid #333;
            width:85px;
        }
        th{
            background-color: #f0f0f0;
        }
        h4, p{
            margin:2px;
        }
    </style>
</head>
<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($id == $s->nota_id): ?>
<body>
    <div class="container">
        <table>
            <caption>
                Penjualan Invoice
            </caption>
            <thead>
                <tr>
                    <th colspan="3">Invoice <strong>#<?php echo e($s->nota_id); ?></strong></th>
                    <th><?php echo e($s -> nota_date); ?></th>
                </tr>
                <tr>
                    <td colspan="2">
                        <h4>Perusahaan: </h4>
                        <p>SI-Penjualan HANUM.<br>
                            Jl. Basuki Rahmad Surabaya<br>
                            085607875343<br>
                            penjualan_hanum@sukses.com
                        </p>
                    </td>
                    <td colspan="2">
                        <h4>Pelanggan: </h4>
                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(($s->customer_id)==($cus->customer_id)): ?>
                        <p><?php echo e($cus->first_name); ?> <?php echo e($cus -> first_name); ?><br>
                        <?php echo e($cus -> phone); ?><br>
                        <?php echo e($cus -> email); ?> <br>
                        <?php echo e($cus -> street); ?><br>
                        <?php echo e($cus -> city); ?><br>
                        <?php echo e($cus -> state); ?><br>
                        <?php echo e($cus -> zip_code); ?>

                        </p>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
                        <tr>
                            <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(($s->user_id)==($u->user_id)): ?>
                                    <th colspan="2">Pegawai <strong> : <?php echo e($u->first_name); ?> <?php echo e($u->last_name); ?></strong></th>
                                    <th colspan="2">#<?php echo e($u->user_id); ?></th>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th>Product Name</th>
                                <th>Quantity</th>
                                <th>Discount</th>
                                <th>Price</th>
                            </tr>
                        <?php $__currentLoopData = $sales_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(($s->nota_id) == ($salesdetail->nota_id)): ?>
                                    <?php if(($salesdetail->product_id) == ($p->product_id)): ?>
                                    <tr>
                                    <td><?php echo e($p -> product_name); ?></td>
                                    <td><?php echo e($salesdetail->quantity); ?></td>
                                    <td>Rp <?php echo e(number_format($salesdetail->discount)); ?></td>
                                    <td>Rp <?php echo e(number_format($salesdetail->selling_price)); ?></td>
                    
                </tr>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
            
            <tfoot>
                <tr>
                    <th colspan="3">Total Price</th>
                
                <?php $__currentLoopData = $sales_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(($s->nota_id) == ($salesdetail->nota_id)): ?>
                                    <?php if(($salesdetail->product_id) == ($p->product_id)): ?>
                                    
                                    <td>Rp <?php echo e(number_format($salesdetail->total_price)); ?></td></tr>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th colspan="3">Pajak</th>
                    <td>10%</td>
                </tr>
                <tr>
                    <th colspan="3">Total Payment</th>
                    <td>Rp <?php echo e(number_format($s->total_payment)); ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
</body>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</html><?php /**PATH C:\xampp\htdocs\laravelkedua\resources\views/transaksi/sales/invoice_pdf.blade.php ENDPATH**/ ?>