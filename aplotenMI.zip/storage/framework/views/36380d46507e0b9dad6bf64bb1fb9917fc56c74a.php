<?php $__env->startSection('title', 'Sales'); ?>

<?php $__env->startSection('container'); ?>

<?php if(\Session::has('kasir') || \Session::has('admin')): ?>
                                <div id="page-wrapper">
                                    <div class="main-page">
                                    <h3 class="title1">Daftar Sales</h3>
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped table-actions">
                                            <a href="salesdcetak_pdf" class="btn btn-primary my-3">CETAK PDF</a>  
                                            </table>
                                        </div>

                                        <div class="bs-example widget-shadow" data-example-id="bordered-table"> 
                                            <table class="table table-bordered">
                                            <thead><tr>
                                                <th>#</th>
                                                    <th>Nota Id</th>
                                                    <th>Pegawai Id</th>
                                                    <th>Customer Id</th>
                                                    <th>Nota Date</th>
                                                    <th>Total Payment</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>                                            
                                                    <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                    <td><?php echo e($s -> nota_id); ?></td>
                                                    <td><?php echo e($s->USFIRST_NAME); ?> <?php echo e($s->USLAST_NAME); ?></td>
						                            <td><?php echo e($s->first_name); ?> <?php echo e($s->last_name); ?></td>
                                                    <td><?php echo e($s -> nota_date); ?></td>
                                                    <td><?php echo e($s -> total_payment); ?></td>
                                                    <td>
                                                    <button type="button" class="label label-warning" data-toggle="modal" data-target="#EditModal<?php echo e($s->nota_id); ?>">
                                                    <svg class="bi bi-pencil" width="3em" height="2em" viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" d="M13.293 3.293a1 1 0 011.414 0l2 2a1 1 0 010 1.414l-9 9a1 1 0 01-.39.242l-3 1a1 1 0 01-1.266-1.265l1-3a1 1 0 01.242-.391l9-9zM14 4l2 2-9 9-3 1 1-3 9-9z" clip-rule="evenodd"></path>
                                                    <path fill-rule="evenodd" d="M14.146 8.354l-2.5-2.5.708-.708 2.5 2.5-.708.708zM5 12v.5a.5.5 0 00.5.5H6v.5a.5.5 0 00.5.5H7v.5a.5.5 0 00.5.5H8v-1.5a.5.5 0 00-.5-.5H7v-.5a.5.5 0 00-.5-.5H5z" clip-rule="evenodd"></path>
                                                    </svg>Detail</button>
                                                    <a href ="salesinvoice_pdf<?php echo e($s->nota_id); ?>">
                                                    <button type="button" class="label label-success">
                                                    <svg class="bi bi-print" width="3em" height="2em" viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" d="M13.293 3.293a1 1 0 011.414 0l2 2a1 1 0 010 1.414l-9 9a1 1 0 01-.39.242l-3 1a1 1 0 01-1.266-1.265l1-3a1 1 0 01.242-.391l9-9zM14 4l2 2-9 9-3 1 1-3 9-9z" clip-rule="evenodd"></path>
                                                    <path fill-rule="evenodd" d="M14.146 8.354l-2.5-2.5.708-.708 2.5 2.5-.708.708zM5 12v.5a.5.5 0 00.5.5H6v.5a.5.5 0 00.5.5H7v.5a.5.5 0 00.5.5H8v-1.5a.5.5 0 00-.5-.5H7v-.5a.5.5 0 00-.5-.5H5z" clip-rule="evenodd"></path>
                                                    </svg>Print Invoice</button></a>
                                                    
                                                        <!-- /Button trigger modal -->
                                                        
                                                        <!-- Modal -->
                                                        <div class="modal fade" id="EditModal<?php echo e($s->nota_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                            <!-- Modal Content -->
                                                                <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLabel">DETAIL PENJUALAN</h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <form class="form-horizontal form-label-left" method="POST">
                                                                                        <table class="table table-bordered">
                                                                                                <thead>
                                                                                                    <tr role="row">
                                                                                                        <th class="datatable-nosort sorting_disabled" rowspan="1" colspan="1">Product Name</th>
                                                                                                        <th class="datatable-nosort sorting_disabled" rowspan="1" colspan="1">Qty</th>
                                                                                                        <th class="datatable-nosort sorting_disabled" rowspan="1" colspan="1">Disc</th>
                                                                                                        <th class="datatable-nosort sorting_disabled" rowspan="1" colspan="1" aria-label="Phone">Price</th>
                                                                                                        <th class="datatable-nosort sorting_disabled" rowspan="1" colspan="1">Total Price</th>
                                                                                                    </tr>
                                                                                                </thead>
                                                                                                <tbody>
                                                                                                    <?php $__currentLoopData = $sales_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                    <?php if($sd->nota_id == $s->nota_id): ?>
                                                                                                    <tr role="row" class="odd" style="cursor:pointer">
                                                                                                        <td><?php echo e($sd->product_name); ?></td>
                                                                                                        <td><?php echo e($sd->quantity); ?></td>
                                                                                                        <td><?php echo e($sd->discount); ?></td>
                                                                                                        <td><?php echo e($sd->selling_price); ?></td>
                                                                                                        <td><?php echo e($sd->total_price); ?></td>
                                                                                                    </tr>
                                                                                                    <?php endif; ?>
                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                </tbody>
                                                                                        </table>
                                                                   
                                                                        </form>
                                                                    </div>
                                                                </div>                                
                                                            </div>                                
                                                        </div>              
                                                    </td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                                
   <script>
    swal("Welcome to Sales!", "You clicked the button!", "success");
   </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelkedua\resources\views/transaksi/sales/index.blade.php ENDPATH**/ ?>