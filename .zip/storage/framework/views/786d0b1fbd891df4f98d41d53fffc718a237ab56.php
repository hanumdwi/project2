<?php $__env->startSection('title', 'sales'); ?>

<?php $__env->startSection('container'); ?>

<div id="page-wrapper">
	<div class="main-page">
    <h3 class="title1">Edit Data Sales :</h3>
        <div class="form-three widget-shadow">
 
	<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<form action="salesupdate" method="post">
		<?php echo e(csrf_field()); ?>


		<input type="hidden" name="id" value="<?php echo e($s->nota_id); ?>"> <br/>
        <div class="form-group">
        <label class="col-md-3 control-label">Customer Id</label>
        <div class="col-md-9">                                            
            <div class="input-group">
            <select class="form-control" id="customer_id" required="" name="customer_id">

                                                        <option disabled selected="">Pilih Kategori</option>
                                                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($cus->customer_id); ?>"><?php echo e($cus->first_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                            </div>
                                </div>


        <div class="form-group">
        <label class="col-md-3 control-label">Sales Name</label>
        <div class="col-md-9">                                            
            <div class="input-group">
            <select class="form-control" id="user_id" required="" name="user_id">
                                                        <option disabled selected="">Pilih Kategori</option>
                                                        <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($u->user_id); ?>"><?php echo e($u->first_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                            </div>
                                </div>

        <div class="form-group">
        <label class="col-md-3 control-label">Nota Date</label>
        <div class="col-md-9">                                            
            <div class="input-group">
                <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                    <input type="date" class="form-control" id="nota_date" name="nota_date" value="<?php echo e($s->nota_date); ?>"><br/></div>                                            
                        <span class="help-block"></span>
                            </div>
                                </div>

        <div class="form-group">
        <label class="col-md-3 control-label">Total Payment</label>
        <div class="col-md-9">                                            
            <div class="input-group">
                <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                    <input type="text" class="form-control" id="total_payment" name="total_payment" value="<?php echo e($s->total_payment); ?>"><br/></div>                                            
                        <span class="help-block"></span>
                            </div>
                                </div>
        
		<button type="submit" class="btn btn-info mt-3">Simpan Data</button>
	</form>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

	
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelkedua\resources\views/transaksi/sales/edit.blade.php ENDPATH**/ ?>