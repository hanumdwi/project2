<?php $__env->startSection('container'); ?>

<div id="page-wrapper">
	<div class="main-page">
    <h3 class="title1">Input Data Product</h3>
        <div class="form-three widget-shadow">
            <form class="form-horizontal" action="productstore" method="post">
            <?php echo csrf_field(); ?>
                <div class="form-group">
                <label for="focusedinput" class="col-sm-2 control-label">Category Id</label>
                    <div class="col-sm-8">
                    <select name="category_id" class="form-control" id="category_id">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($c->status == 1): ?>
                        <option value="<?php echo e($c->category_id); ?>"><?php echo e($c->category_name); ?></option>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
                    </select>
                    </div></div>
        
          
            <form class="form-horizontal">
                <div class="form-group">
                <label for="focusedinput" class="col-sm-2 control-label">Product Name</label>
                    <div class="col-sm-8">
                    <input type="text" class="form-control1" id="product_name" name="product_name" placeholder="Default Input">
                    </div>
                        <div class="col-sm-2">
                        </div>
                    </div>

                        
          
            <form class="form-horizontal">
                <div class="form-group">
                <label for="focusedinput" class="col-sm-2 control-label">Product Price</label>
                    <div class="col-sm-8">
                    <input type="text" class="form-control1" id="product_price" name="product_price" placeholder="Default Input">
                    </div>
                        <div class="col-sm-2">
                        </div></div>

            <form class="form-horizontal">
                <div class="form-group">
                <label for="focusedinput" class="col-sm-2 control-label">Product Stock</label>
                    <div class="col-sm-8">
                    <input type="text" class="form-control1" id="product_stock" name="product_stock" placeholder="Default Input">
                    </div>
                        <div class="col-sm-2">
                        </div></div>

       
            <form class="form-horizontal">
                <div class="form-group">
                <label for="focusedinput" class="col-sm-2 control-label">Explanation</label>
                    <div class="col-sm-8">
                    <input type="text" class="form-control1" id="explanation" name="explanation" placeholder="Default Input">
                    </div>
                        <div class="col-sm-2">
                        </div></div>
                

<button type="submit" class="btn btn-primary">Submit</button> </form> 
</div>
                            
                        </div>
                    </div>                    
                    
                </div>
                <!-- END PAGE CONTENT WRAPPER -->  
                <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project2-master\project2-master\resources\views/master/product/create.blade.php ENDPATH**/ ?>